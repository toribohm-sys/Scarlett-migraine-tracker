# Scarlett Migraine Tracker — Native Android source scaffold

This is the first native Android source package created from the approved browser prototype.

Implemented in this scaffold:
- Clean SQLite database (`scarlett_migraine.db`)
- Day + timestamped migraine report schema
- Non-destructive migration rule placeholder
- Native Android app entry point
- One-tap “No migraine now” saving a timestamped 0/10 report
- Android notification receiver foundation
- Approved burgundy/gold theme foundation

Still to implement before this is a production handover:
- Full Today accordion UI (migraine report, period, amitriptyline)
- Calendar and Patterns screens
- Exact weekday/weekend alarm scheduling (7 AM weekdays / 9 AM weekends)
- Evening migraine + medication reminder times after they are chosen
- Google Drive backup authentication, versioned backup, and tested restore
- CSV export
- LB launcher icon resource integration at Android adaptive-icon sizes
- Production signing and APK compilation/testing

Important: this ZIP is SOURCE CODE, not an installable APK. No claim is made that an APK has been built in this environment.


## Stage 2 update
Implemented native daily-entry UI logic for:
- 0–10 migraine pain
- approved symptom list only
- Cefaly Acute/Preventative + 0–60 minutes with 60/20 defaults
- comments
- period yes/no
- amitriptyline taken + 10 mg dose increments, default 50 mg
- derived migraine YES/NO/INCOMPLETE logic
- next morning alarm calculation: 7 AM weekdays, 9 AM weekends

Still required: reschedule the following morning after alarm delivery/reboot, notification permission UX, full Calendar/Patterns/Settings UI, Drive backup/restore, CSV, production icon resources, compilation/signing/device tests.
