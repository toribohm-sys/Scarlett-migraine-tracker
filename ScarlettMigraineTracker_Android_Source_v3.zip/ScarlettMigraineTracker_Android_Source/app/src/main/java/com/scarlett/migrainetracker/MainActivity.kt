package com.scarlett.migrainetracker
import android.app.*
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate
import java.time.LocalTime

class MainActivity: AppCompatActivity() {
 private lateinit var db:MigraineDb
 private lateinit var status:TextView
 private fun today()=LocalDate.now().toString()
 private fun now()=LocalTime.now().withSecond(0).withNano(0).toString()

 override fun onCreate(savedInstanceState:Bundle?) {
  super.onCreate(savedInstanceState); db=MigraineDb(this)
  ReminderScheduler.createChannels(this); ReminderScheduler.scheduleMorning(this)
  val scroll=ScrollView(this)
  val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,32,32,40) }
  box.addView(TextView(this).apply { text="Migraine Tracker"; textSize=28f })
  box.addView(TextView(this).apply { text="Today"; textSize=22f })
  status=TextView(this); box.addView(status)

  box.addView(Button(this).apply { text="✓ No migraine now"; setOnClickListener {
   db.addReport(today(),now(),0,comment="No migraine now."); refresh()
  }})
  box.addView(Button(this).apply { text="+ Report migraine"; setOnClickListener { showMigraineForm() }})
  box.addView(Button(this).apply { text="Period check-in"; setOnClickListener { showPeriod() }})
  box.addView(Button(this).apply { text="Amitriptyline check-in"; setOnClickListener { showMedication() }})
  scroll.addView(box); setContentView(scroll); refresh()
 }

 private fun refresh(){ status.text="Migraine: "+db.migraineStatus(today()) }

 private fun showMigraineForm() {
  val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,0,24,0) }
  val pain=SeekBar(this).apply { max=10 }
  val painLabel=TextView(this).apply { text="Pain: 0 / 10" }
  pain.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
   override fun onProgressChanged(s:SeekBar?,v:Int,f:Boolean){ painLabel.text="Pain: $v / 10" }
   override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){}
  })
  layout.addView(painLabel); layout.addView(pain)
  val symptomNames=arrayOf("Dizziness / vertigo","Nausea","Temple pressure","Extreme tiredness","Other")
  val checks=symptomNames.map { name -> CheckBox(this).apply { text=name; layout.addView(this) } }
  val cefaly=CheckBox(this).apply { text="Cefaly used"; layout.addView(this) }
  val acute=RadioButton(this).apply { text="Acute"; isChecked=true }
  val preventative=RadioButton(this).apply { text="Preventative" }
  val modes=RadioGroup(this).apply { orientation=RadioGroup.HORIZONTAL; addView(acute); addView(preventative); layout.addView(this) }
  val minutes=SeekBar(this).apply { max=60; progress=60; layout.addView(this) }
  modes.setOnCheckedChangeListener { _,id -> minutes.progress=if(id==preventative.id)20 else 60 }
  val comment=EditText(this).apply { hint="Comments / additional information"; layout.addView(this) }
  AlertDialog.Builder(this).setTitle("Report migraine").setView(layout)
   .setPositiveButton("Save"){_,_->
    val symptoms=checks.filter{it.isChecked}.joinToString("|"){it.text.toString()}
    val mode=if(!cefaly.isChecked)null else if(preventative.isChecked)"Preventative" else "Acute"
    db.addReport(today(),now(),pain.progress,symptoms,comment.text.toString(),cefaly.isChecked,mode,if(cefaly.isChecked)minutes.progress else 0)
    refresh()
   }.setNegativeButton("Cancel",null).show()
 }

 private fun showPeriod() {
  val options=arrayOf("No period today","Period today")
  AlertDialog.Builder(this).setTitle("Period").setSingleChoiceItems(options,0,null)
   .setPositiveButton("Save"){d,_->
    val pos=(d as AlertDialog).listView.checkedItemPosition; db.recordPeriod(today(),pos==1); d.dismiss()
   }.setNegativeButton("Cancel",null).show()
 }

 private fun showMedication() {
  val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,0,24,0) }
  val taken=CheckBox(this).apply { text="Taken today"; layout.addView(this) }
  val doseLabel=TextView(this).apply { text="Dose: 50 mg"; layout.addView(this) }
  val dose=SeekBar(this).apply { max=9; progress=4; layout.addView(this) }
  dose.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
   override fun onProgressChanged(s:SeekBar?,v:Int,f:Boolean){ doseLabel.text="Dose: ${(v+1)*10} mg" }
   override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){}
  })
  AlertDialog.Builder(this).setTitle("Amitriptyline").setView(layout)
   .setPositiveButton("Save"){_,_-> db.recordMedication(today(),taken.isChecked,(dose.progress+1)*10) }
   .setNegativeButton("Cancel",null).show()
 }
}
