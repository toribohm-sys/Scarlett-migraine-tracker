package com.scarlett.migrainetracker
import android.app.*
import android.content.*
import java.time.*
import java.util.*

object ReminderScheduler {
 const val CHANNEL="migraine_reminders"
 fun createChannels(context:Context) {
  val nm=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
  nm.createNotificationChannel(NotificationChannel(CHANNEL,"Migraine reminders",NotificationManager.IMPORTANCE_DEFAULT))
 }
 fun scheduleMorning(context:Context) {
  val now=ZonedDateTime.now()
  var next=now.withHour(if(now.dayOfWeek in setOf(DayOfWeek.SATURDAY,DayOfWeek.SUNDAY))9 else 7).withMinute(0).withSecond(0).withNano(0)
  if(!next.isAfter(now)) {
   next=next.plusDays(1)
   next=next.withHour(if(next.dayOfWeek in setOf(DayOfWeek.SATURDAY,DayOfWeek.SUNDAY))9 else 7)
  }
  val intent=Intent(context,ReminderReceiver::class.java).putExtra("id",101)
   .putExtra("title","Morning migraine check-in").putExtra("text","How are you feeling now?")
  val pi=PendingIntent.getBroadcast(context,101,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  val alarm=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
  alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next.toInstant().toEpochMilli(),pi)
 }
}
