package com.scarlett.migrainetracker
import android.app.*
import android.content.*
import androidx.core.app.NotificationCompat

class ReminderReceiver: BroadcastReceiver() {
 override fun onReceive(context:Context,intent:Intent) {
  val nm=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
  val channel="migraine_reminders"
  nm.createNotificationChannel(NotificationChannel(channel,"Migraine reminders",NotificationManager.IMPORTANCE_DEFAULT))
  val title=intent.getStringExtra("title") ?: "Migraine Tracker"
  val text=intent.getStringExtra("text") ?: "Time for your check-in."
  nm.notify(intent.getIntExtra("id",1), NotificationCompat.Builder(context,channel)
    .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(text)
    .setAutoCancel(true).build())
 }
}
