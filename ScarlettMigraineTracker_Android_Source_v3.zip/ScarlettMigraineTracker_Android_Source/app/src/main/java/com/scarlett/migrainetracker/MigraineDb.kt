package com.scarlett.migrainetracker
import android.content.*
import android.database.sqlite.*

class MigraineDb(ctx: Context): SQLiteOpenHelper(ctx,"scarlett_migraine.db",null,1) {
 override fun onConfigure(db: SQLiteDatabase) { db.setForeignKeyConstraintsEnabled(true) }
 override fun onCreate(db: SQLiteDatabase) {
  db.execSQL("""CREATE TABLE day(date TEXT PRIMARY KEY, period_recorded INTEGER NOT NULL DEFAULT 0,
    period INTEGER NOT NULL DEFAULT 0, flow TEXT, med_recorded INTEGER NOT NULL DEFAULT 0,
    med_taken INTEGER NOT NULL DEFAULT 0, dose_mg INTEGER)""")
  db.execSQL("""CREATE TABLE migraine_report(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,
    time TEXT NOT NULL,pain INTEGER NOT NULL CHECK(pain BETWEEN 0 AND 10),symptoms TEXT NOT NULL DEFAULT '',
    comment TEXT NOT NULL DEFAULT '',cefaly INTEGER NOT NULL DEFAULT 0,cefaly_mode TEXT,cefaly_minutes INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY(date) REFERENCES day(date) ON DELETE CASCADE)""")
  db.execSQL("CREATE INDEX idx_report_date_time ON migraine_report(date,time)")
 }
 override fun onUpgrade(db: SQLiteDatabase, oldVersion:Int, newVersion:Int) {
  // Production invariant: migrations are additive/non-destructive. Never DROP user history.
 }
 fun ensureDay(date:String) {
  writableDatabase.execSQL("INSERT OR IGNORE INTO day(date) VALUES(?)", arrayOf(date))
 }
 fun addReport(date:String,time:String,pain:Int,symptoms:String="",comment:String="",cefaly:Boolean=false,mode:String?=null,minutes:Int=0) {
  require(pain in 0..10); require(minutes in 0..60)
  ensureDay(date)
  val v=ContentValues().apply {
   put("date",date); put("time",time); put("pain",pain); put("symptoms",symptoms); put("comment",comment)
   put("cefaly",if(cefaly)1 else 0); put("cefaly_mode",mode); put("cefaly_minutes",minutes)
  }
  writableDatabase.insertOrThrow("migraine_report",null,v)
 }
 fun recordPeriod(date:String, hasPeriod:Boolean, flow:String?=null) {
  ensureDay(date); val v=ContentValues().apply {
   put("period_recorded",1); put("period",if(hasPeriod)1 else 0); put("flow",if(hasPeriod) flow else null as String?)
  }
  writableDatabase.update("day",v,"date=?",arrayOf(date))
 }
 fun recordMedication(date:String,taken:Boolean,doseMg:Int) {
  require(doseMg in 10..100 && doseMg%10==0)
  ensureDay(date); val v=ContentValues().apply {
   put("med_recorded",1); put("med_taken",if(taken)1 else 0); put("dose_mg",doseMg)
  }
  writableDatabase.update("day",v,"date=?",arrayOf(date))
 }
 fun migraineStatus(date:String): String {
  readableDatabase.rawQuery("SELECT COUNT(*), COALESCE(MAX(pain),0) FROM migraine_report WHERE date=?",arrayOf(date)).use {
   it.moveToFirst(); val count=it.getInt(0); val max=it.getInt(1)
   return if(count==0) "INCOMPLETE" else if(max>0) "YES" else "NO"
  }
 }
}
